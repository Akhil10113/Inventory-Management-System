import api from "./api";

// ==========================================
// GET VENDORS
// ==========================================

export const getVendors = async () => {
  const { data } = await api.get("/vendors");
  return data;
};


// ==========================================
// GET MATERIAL CATEGORIES
// ==========================================

export const getCategories = async () => {
  const { data } = await api.get("/categories");
  return data;
};


// ==========================================
// GET MATERIAL TYPES + UNITS
// ==========================================

export const getUnitAndTypeList = async (categoryId) => {
  const { data } = await api.post(
    "/getUnitAndTypeList",
    {
      materialCategoryId: categoryId,
    }
  );

  return data;
};


// ==========================================
// ADD PURCHASE
// ==========================================

export const addPurchase = async (purchaseData) => {
  const { data } = await api.post(
    "/addPurchaseDetail",
    purchaseData
  );

  return data;
};


// ==========================================
// PURCHASE REPORT
// ==========================================

export const getPurchaseReport = async (reportData) => {
  const { data } = await api.post(
    "/report/controller/getPurchaseDetails",
    reportData
  );

  return data;
};