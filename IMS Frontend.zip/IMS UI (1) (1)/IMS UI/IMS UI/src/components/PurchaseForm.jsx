import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import { Save } from "lucide-react";

import SuccessModal from "./ui/SuccessModal";
import { purchaseSchema } from "../schemas/purchaseSchema";

import {
  getVendors,
  getCategories,
  getUnitAndTypeList,
  addPurchase,
} from "../services/inventoryService";

import "./PurchaseForm.css";

export default function PurchaseForm() {

  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(purchaseSchema),

    defaultValues: {
      vendorName: "",
      materialCategoryId: "",
      materialTypeId: "",
      unitId: "",
      brandName: "",
      quantity: "",
      purchaseDate: "",
      purchaseAmount: "",
    },
  });


  // ==========================================
  // STATE
  // ==========================================

  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [types, setTypes] = useState([]);
  const [units, setUnits] = useState([]);

  const [loadingVendors, setLoadingVendors] = useState(false);
  const [loadingCategories, setLoadingCategories] = useState(false);
  const [loadingTypes, setLoadingTypes] = useState(false);
  const [saving, setSaving] = useState(false);

  const [successData, setSuccessData] = useState(null);


  // ==========================================
  // WATCH VALUES
  // ==========================================

  const selectedVendor = watch("vendorName");
  const selectedCategory = watch("materialCategoryId");


  // ==========================================
  // LOAD VENDORS
  // ==========================================

  useEffect(() => {

    const loadVendors = async () => {

      try {

        setLoadingVendors(true);

        const data = await getVendors();

        console.log("Vendors received:", data);

        setVendors(Array.isArray(data) ? data : []);

      } catch (error) {

        console.error("Error loading vendors:", error);

        toast.error("Unable to load vendors");

        setVendors([]);

      } finally {

        setLoadingVendors(false);

      }
    };

    loadVendors();

  }, []);


  // ==========================================
  // LOAD CATEGORIES
  // ==========================================

  useEffect(() => {

    if (!selectedVendor) {

      setCategories([]);
      setTypes([]);
      setUnits([]);

      setValue("materialCategoryId", "");
      setValue("materialTypeId", "");
      setValue("unitId", "");

      return;
    }


    const loadCategories = async () => {

      try {

        setLoadingCategories(true);

        const data = await getCategories();

        console.log("Categories received:", data);

        setCategories(Array.isArray(data) ? data : []);

      } catch (error) {

        console.error("Error loading categories:", error);

        toast.error("Unable to load categories");

        setCategories([]);

      } finally {

        setLoadingCategories(false);

      }
    };

    loadCategories();

  }, [selectedVendor, setValue]);


  // ==========================================
  // LOAD TYPES + UNITS
  // ==========================================

  useEffect(() => {

    if (!selectedCategory) {

      setTypes([]);
      setUnits([]);

      setValue("materialTypeId", "");
      setValue("unitId", "");

      return;
    }


    const loadMaterialData = async () => {

      try {

        setLoadingTypes(true);

        const data =
          await getUnitAndTypeList(selectedCategory);

        console.log(
          "Material type/unit response:",
          data
        );


        setTypes(
          Array.isArray(data?.materialTypeList)
            ? data.materialTypeList
            : []
        );


        setUnits(
          Array.isArray(data?.unitList)
            ? data.unitList
            : []
        );

      } catch (error) {

        console.error(
          "Error loading material types and units:",
          error
        );

        toast.error(
          "Unable to load material data"
        );

        setTypes([]);
        setUnits([]);

      } finally {

        setLoadingTypes(false);

      }
    };

    loadMaterialData();

  }, [selectedCategory, setValue]);


  // ==========================================
  // SUBMIT PURCHASE
  // ==========================================

  const onSubmit = async (formData) => {

    try {

      setSaving(true);

      const purchaseData = {

        vendorName: formData.vendorName,

        materialCategoryId:
          formData.materialCategoryId,

        materialTypeId:
          formData.materialTypeId,

        unitId:
          formData.unitId,

        brandName:
          formData.brandName,

        quantity:
          Number(formData.quantity),

        purchaseDate:
          formData.purchaseDate,

        purchaseAmount:
          Number(formData.purchaseAmount),
      };


      console.log(
        "Purchase data being sent:",
        purchaseData
      );


      const response =
        await addPurchase(purchaseData);


      console.log(
        "Purchase response:",
        response
      );


      setSuccessData({
        message:
          response?.message ||
          "Purchase details added successfully",

        transactionId:
          response?.purchase?.transactionId ||
          "",
      });


      reset();

      setCategories([]);
      setTypes([]);
      setUnits([]);


    } catch (error) {

      console.error(
        "Error saving purchase:",
        error
      );

      toast.error(
        error?.response?.data?.message ||
        "Failed to save purchase."
      );

    } finally {

      setSaving(false);

    }
  };


  // ==========================================
  // UI
  // ==========================================

  return (

    <div className="purchase-page">

      <div className="purchase-card">

        {/* HEADER */}

        <div className="purchase-header">

          <h1>Purchase Details</h1>

          <p>
            Fill in the information below to create
            a purchase transaction.
          </p>

        </div>


        {/* FORM */}

        <form
          onSubmit={handleSubmit(onSubmit)}
        >

          <div className="purchase-grid">


            {/* ================================
                VENDOR
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="vendorName">
                Vendor
              </label>

              <select
                id="vendorName"
                className="purchase-select"
                {...register("vendorName")}
              >

                <option value="">
                  {loadingVendors
                    ? "Loading Vendors..."
                    : "-- Select Vendor --"}
                </option>


                {vendors.map((vendor) => (

                  <option
                    key={vendor.vendorId}
                    value={vendor.vendorName}
                  >
                    {vendor.vendorName}
                  </option>

                ))}

              </select>


              {errors.vendorName && (

                <span className="field-error">
                  {errors.vendorName.message}
                </span>

              )}

            </div>


            {/* ================================
                CATEGORY
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="materialCategoryId">
                Material Category
              </label>

              <select
                id="materialCategoryId"
                className="purchase-select"
                disabled={
                  !selectedVendor ||
                  loadingCategories
                }
                {...register("materialCategoryId")}
              >

                <option value="">

                  {!selectedVendor
                    ? "Select Vendor First"
                    : loadingCategories
                    ? "Loading Categories..."
                    : "-- Select Category --"}

                </option>


                {categories.map((category) => (

                  <option
                    key={category.categoryId}
                    value={category.categoryId}
                  >
                    {category.categoryName}
                  </option>

                ))}

              </select>


              {errors.materialCategoryId && (

                <span className="field-error">
                  {errors.materialCategoryId.message}
                </span>

              )}

            </div>


            {/* ================================
                MATERIAL TYPE
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="materialTypeId">
                Material Type
              </label>

              <select
                id="materialTypeId"
                className="purchase-select"
                disabled={
                  !selectedCategory ||
                  loadingTypes
                }
                {...register("materialTypeId")}
              >

                <option value="">

                  {!selectedCategory
                    ? "Select Category First"
                    : loadingTypes
                    ? "Loading Types..."
                    : "-- Select Type --"}

                </option>


                {types.map((type) => (

                  <option
                    key={type.typeId}
                    value={type.typeId}
                  >
                    {type.typeName}
                  </option>

                ))}

              </select>


              {errors.materialTypeId && (

                <span className="field-error">
                  {errors.materialTypeId.message}
                </span>

              )}

            </div>


            {/* ================================
                UNIT
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="unitId">
                Unit
              </label>

              <select
                id="unitId"
                className="purchase-select"
                disabled={
                  !selectedCategory ||
                  loadingTypes
                }
                {...register("unitId")}
              >

                <option value="">

                  {!selectedCategory
                    ? "Select Category First"
                    : loadingTypes
                    ? "Loading Units..."
                    : "-- Select Unit --"}

                </option>


                {units.map((unit) => (

                  <option
                    key={unit.unitId}
                    value={unit.unitId}
                  >
                    {unit.unitName}
                  </option>

                ))}

              </select>


              {errors.unitId && (

                <span className="field-error">
                  {errors.unitId.message}
                </span>

              )}

            </div>


            {/* ================================
                BRAND
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="brandName">
                Brand Name
              </label>

              <input
                id="brandName"
                type="text"
                className="purchase-input"
                placeholder="Enter brand name"
                {...register("brandName")}
              />


              {errors.brandName && (

                <span className="field-error">
                  {errors.brandName.message}
                </span>

              )}

            </div>


            {/* ================================
                QUANTITY
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="quantity">
                Quantity
              </label>

              <input
                id="quantity"
                type="number"
                min="1"
                className="purchase-input"
                placeholder="Enter quantity"
                {...register("quantity")}
              />


              {errors.quantity && (

                <span className="field-error">
                  {errors.quantity.message}
                </span>

              )}

            </div>


            {/* ================================
                PURCHASE DATE
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="purchaseDate">
                Purchase Date
              </label>

              <input
                id="purchaseDate"
                type="date"
                className="purchase-input"
                max={
                  new Date()
                    .toISOString()
                    .split("T")[0]
                }
                {...register("purchaseDate")}
              />


              {errors.purchaseDate && (

                <span className="field-error">
                  {errors.purchaseDate.message}
                </span>

              )}

            </div>


            {/* ================================
                PURCHASE AMOUNT
            ================================= */}

            <div className="purchase-field">

              <label htmlFor="purchaseAmount">
                Purchase Amount
              </label>

              <input
                id="purchaseAmount"
                type="number"
                step="0.01"
                min="0"
                className="purchase-input"
                placeholder="Enter purchase amount"
                {...register("purchaseAmount")}
              />


              {errors.purchaseAmount && (

                <span className="field-error">
                  {errors.purchaseAmount.message}
                </span>

              )}

            </div>

          </div>


          {/* SAVE BUTTON */}

          <div className="purchase-actions">

            <button
              type="submit"
              className="save-purchase-button"
              disabled={saving}
            >

              <Save size={18} />

              {saving
                ? "Saving..."
                : "Save Purchase"}

            </button>

          </div>

        </form>

      </div>


      {/* SUCCESS */}

      <SuccessModal
        open={successData !== null}
        message={successData?.message}
        transactionId={
          successData?.transactionId
        }
        onClose={() =>
          setSuccessData(null)
        }
      />

    </div>
  );
}