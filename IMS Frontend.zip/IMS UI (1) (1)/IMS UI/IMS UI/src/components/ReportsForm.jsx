import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Search } from "lucide-react";
import toast from "react-hot-toast";

import {
  getVendors,
  getPurchaseReport,
} from "../services/inventoryService";

import "./ReportsForm.css";

export default function ReportsForm() {

  const {
    register,
    handleSubmit,
  } = useForm({
    defaultValues: {
      vendorName: "",
      fromDate: "",
      toDate: "",
    },
  });


  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [reportData, setReportData] = useState([]);


  // ==========================================
  // LOAD VENDORS
  // ==========================================

  useEffect(() => {

    const loadVendors = async () => {

      try {

        const data = await getVendors();

        console.log(
          "Report vendors:",
          data
        );

        setVendors(
          Array.isArray(data) ? data : []
        );

      } catch (error) {

        console.error(
          "Error loading report vendors:",
          error
        );

        toast.error(
          "Unable to load vendors"
        );

      } finally {

        setLoading(false);

      }
    };

    loadVendors();

  }, []);


  // ==========================================
  // GET REPORT
  // ==========================================

  const onSubmit = async (formData) => {

    try {

      setSearching(true);

      console.log(
        "Report request:",
        formData
      );


      const data =
        await getPurchaseReport(formData);


      console.log(
        "Report response:",
        data
      );


      setReportData(
        Array.isArray(data)
          ? data
          : []
      );


    } catch (error) {

      console.error(
        "Error loading report:",
        error
      );

      toast.error(
        error?.response?.data?.message ||
        "Unable to load purchase report"
      );

      setReportData([]);

    } finally {

      setSearching(false);

    }
  };


  return (

    <div className="reports-page">

      <div className="reports-card">

        {/* HEADER */}

        <div className="reports-header">

          <h1>
            Vendor Purchase Report
          </h1>

          <p>
            Search purchases made between
            two dates.
          </p>

        </div>


        {/* SEARCH FORM */}

        <form
          onSubmit={handleSubmit(onSubmit)}
        >

          <div className="report-search-grid">


            {/* VENDOR */}

            <div className="report-field">

              <label>
                Vendor
              </label>

              <select
                className="report-select"
                disabled={loading}
                {...register("vendorName")}
              >

                <option value="">
                  {loading
                    ? "Loading Vendors..."
                    : "-- Select Vendor --"}
                </option>


                {vendors.map((vendor) => (

                  <option
                    key={vendor.vendorId}
                    value={vendor.vendorName}
                  >
                    {vendor.vendorName}
                  </option>

                ))}

              </select>

            </div>


            {/* FROM DATE */}

            <div className="report-field">

              <label>
                From Date
              </label>

              <input
                type="date"
                className="report-input"
                {...register("fromDate")}
              />

            </div>


            {/* TO DATE */}

            <div className="report-field">

              <label>
                To Date
              </label>

              <input
                type="date"
                className="report-input"
                {...register("toDate")}
              />

            </div>

          </div>


          {/* SEARCH BUTTON */}

          <div className="report-actions">

            <button
              type="submit"
              className="report-button"
              disabled={searching}
            >

              <Search size={18} />

              {searching
                ? "Loading..."
                : "Get Report"}

            </button>

          </div>

        </form>


        {/* REPORT */}

        {reportData.length > 0 && (

          <div className="report-table-container">

            <table className="report-table">

              <thead>

                <tr>

                  <th>
                    Transaction ID
                  </th>

                  <th>
                    Vendor
                  </th>

                  <th>
                    Brand
                  </th>

                  <th>
                    Category
                  </th>

                  <th>
                    Type
                  </th>

                  <th>
                    Quantity
                  </th>

                  <th>
                    Amount
                  </th>

                  <th>
                    Purchase Date
                  </th>

                  <th>
                    Status
                  </th>

                </tr>

              </thead>


              <tbody>

                {reportData.map(
                  (purchase) => (

                    <tr
                      key={
                        purchase.purchaseId
                      }
                    >

                      <td className="transaction-id">
                        {
                          purchase.transactionId
                        }
                      </td>

                      <td>
                        {
                          purchase.vendorName
                        }
                      </td>

                      <td>
                        {
                          purchase.brandName
                        }
                      </td>

                      <td>
                        {
                          purchase.materialCategoryId
                        }
                      </td>

                      <td>
                        {
                          purchase.materialTypeId
                        }
                      </td>

                      <td>
                        {
                          purchase.quantity
                        }
                      </td>

                      <td className="amount">
                        ₹{" "}
                        {Number(
                          purchase.purchaseAmount
                        ).toFixed(2)}
                      </td>

                      <td>
                        {
                          purchase.purchaseDate
                        }
                      </td>

                      <td>

                        <span className="status">
                          {
                            purchase.status
                          }
                        </span>

                      </td>

                    </tr>

                  )
                )}

              </tbody>

            </table>

          </div>

        )}


        {!searching &&
          reportData.length === 0 && (

            <div className="no-report">

              Select a vendor and date range,
              then click
              <strong> Get Report </strong>
              to view purchase history.

            </div>

          )}

      </div>

    </div>
  );
}