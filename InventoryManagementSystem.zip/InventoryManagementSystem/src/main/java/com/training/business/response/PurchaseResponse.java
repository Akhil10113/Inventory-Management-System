package com.training.business.response;

import com.training.business.bean.PurchaseBean;

public class PurchaseResponse {

    private String status;
    private String message;
    private PurchaseBean purchase;

    public PurchaseResponse(
            String status,
            String message,
            PurchaseBean purchase) {

        this.status = status;
        this.message = message;
        this.purchase = purchase;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public PurchaseBean getPurchase() {
        return purchase;
    }
}