package com.training.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.business.bean.PurchaseBean;
import com.training.dao.PurchaseDataAccess;

@Service
@Transactional
public class PurchaseServiceImpl implements PurchaseService {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(PurchaseServiceImpl.class);

    @Autowired
    private PurchaseDataAccess purchaseDataAccess;

    @Override
    public PurchaseBean addPurchaseDetails(PurchaseBean purchaseBean)
            throws Exception {

        LOGGER.info("Inside addPurchaseDetails method");

        String transactionId = transactionIdGenerator(
                purchaseBean.getVendorName(),
                purchaseBean.getMaterialCategoryId(),
                purchaseBean.getPurchaseDate());

        purchaseBean.setTransactionId(transactionId);

        LOGGER.info("Generated transaction ID: {}", transactionId);

        PurchaseBean savedPurchaseBean =
                purchaseDataAccess.savePurchaseDetail(purchaseBean);

        LOGGER.info("Purchase saved successfully. Purchase ID: {}",
                savedPurchaseBean.getPurchaseId());

        return savedPurchaseBean;
    }

    private String transactionIdGenerator(
            String vendorName,
            String materialCategoryId,
            Date purchaseDate) {

        String vendorPrefix = safePrefix(vendorName);

        String categoryPrefix = safePrefix(materialCategoryId);

        String datePart =
                new SimpleDateFormat(
                        "MMddyyyy",
                        Locale.ENGLISH)
                        .format(purchaseDate);

        return "P_"
                + vendorPrefix
                + "_"
                + datePart
                + "_"
                + categoryPrefix;
    }

    private String safePrefix(String value) {

        if (value == null || value.trim().isEmpty()) {
            return "NA";
        }

        String clean =
                value.trim().replaceAll("\\s+", "");

        if (clean.length() >= 3) {
            return clean.substring(0, 3)
                    .toUpperCase(Locale.ENGLISH);
        }

        return clean.toUpperCase(Locale.ENGLISH);
    }
}