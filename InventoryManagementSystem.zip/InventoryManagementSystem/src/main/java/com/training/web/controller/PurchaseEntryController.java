package com.training.web.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.training.business.bean.MaterialCategoryBean;
import com.training.business.bean.MaterialTypeBean;
import com.training.business.bean.PurchaseBean;
import com.training.business.bean.UnitBean;
import com.training.business.bean.VendorBean;
import com.training.business.response.PurchaseResponse;
import com.training.business.response.UnitAndTypeResponse;
import com.training.exceptions.MicroServiceException;
import com.training.service.PurchaseService;
import com.training.web.client.MaterialCategoryConsumer;
import com.training.web.client.MaterialTypeConsumer;
import com.training.web.client.UnitServiceConsumer;
import com.training.web.client.VendorServiceConsumer;

@CrossOrigin(
    origins = {
        "http://localhost:5173",
        "http://localhost:3000"
    }
)
@RestController
@SessionAttributes({"purchaseBean"})
public class PurchaseEntryController {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(PurchaseEntryController.class);

    @Autowired
    private PurchaseService purchaseService;

    @Autowired
    private VendorServiceConsumer vendorServiceConsumer;

    @Autowired
    private MaterialCategoryConsumer materialCategoryConsumer;

    @Autowired
    private UnitServiceConsumer unitServiceConsumer;

    @Autowired
    private MaterialTypeConsumer materialTypeConsumer;

    @GetMapping("purchaseEntry")
    public ResponseEntity<PurchaseBean> purchaseEntry()
            throws Exception {

        return ResponseEntity.ok(new PurchaseBean());
    }

    @GetMapping("vendors")
    public ResponseEntity<List<VendorBean>> generateVendorList()
            throws MicroServiceException {

        List<VendorBean> vendorList =
                vendorServiceConsumer.getVendorBeanList();

        if (vendorList == null) {
            vendorList = List.of();
        }

        return ResponseEntity.ok(vendorList);
    }

    @GetMapping("categories")
    public ResponseEntity<List<MaterialCategoryBean>>
            generateCategoryList()
            throws MicroServiceException {

        List<MaterialCategoryBean> categoryList =
                materialCategoryConsumer
                        .getMaterialCategoryBeanList();

        if (categoryList == null) {
            categoryList = List.of();
        }

        return ResponseEntity.ok(categoryList);
    }

    @PostMapping("getUnitAndTypeList")
    public ResponseEntity<UnitAndTypeResponse>
            generateUnitAndTypeList(
                    @RequestBody PurchaseBean purchaseBean,
                    HttpSession session)
                    throws MicroServiceException {

        String categoryId =
                purchaseBean.getMaterialCategoryId();

        List<UnitBean> unitBeans =
                unitServiceConsumer
                        .hitGetUnitsByCategoryId(categoryId);

        List<MaterialTypeBean> materialTypeBeans =
                materialTypeConsumer
                        .hitGetTypesBasedOnCategoryId(categoryId);

        session.setAttribute(
                "purchaseBean",
                purchaseBean);

        return ResponseEntity.ok(
                new UnitAndTypeResponse(
                        unitBeans == null
                                ? List.of()
                                : unitBeans,
                        materialTypeBeans == null
                                ? List.of()
                                : materialTypeBeans));
    }

    @PostMapping("addPurchaseDetail")
    public ResponseEntity<PurchaseResponse>
            addPurchaseDetail(
                    @RequestBody @Valid PurchaseBean purchaseBean,
                    HttpSession session)
                    throws Exception {

        LOGGER.info(
                "Execution Started [addPurchaseDetail]");

        LOGGER.info(
                "Purchase request: {}",
                purchaseBean);

        PurchaseBean savedPurchaseBean =
                purchaseService
                        .addPurchaseDetails(purchaseBean);

        session.setAttribute(
                "purchaseBean",
                savedPurchaseBean);

        LOGGER.info(
                "Purchase saved successfully");

        LOGGER.info(
                "Execution over [addPurchaseDetail]");

        return ResponseEntity.ok(
                new PurchaseResponse(
                        "SUCCESS",
                        "Purchase details added successfully",
                        savedPurchaseBean));
    }
}