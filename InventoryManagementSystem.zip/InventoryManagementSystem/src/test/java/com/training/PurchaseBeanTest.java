package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Date;

import org.junit.jupiter.api.Test;

import com.training.business.bean.PurchaseBean;

class PurchaseBeanTest {

    @Test
    void testPurchaseBeanConstructor() {

        Date purchaseDate = new Date();

        PurchaseBean bean = new PurchaseBean(
                1,
                "TXN001",
                "Vendor1",
                "CAT001",
                "TYPE001",
                1000.0,
                "Brand1",
                "UNIT001",
                10,
                5000.0,
                purchaseDate,
                "Category1",
                "Type1",
                "Unit1",
                "ACTIVE"
        );

        assertEquals(Integer.valueOf(1), bean.getPurchaseId());
        assertEquals("TXN001", bean.getTransactionId());
        assertEquals("Vendor1", bean.getVendorName());
        assertEquals("CAT001", bean.getMaterialCategoryId());
        assertEquals("TYPE001", bean.getMaterialTypeId());
        assertEquals(Double.valueOf(1000.0), bean.getBalance());
        assertEquals("Brand1", bean.getBrandName());
        assertEquals("UNIT001", bean.getUnitId());
        assertEquals(Integer.valueOf(10), bean.getQuantity());
        assertEquals(Double.valueOf(5000.0), bean.getPurchaseAmount());
        assertEquals(purchaseDate, bean.getPurchaseDate());
        assertEquals("Category1", bean.getMaterialCategoryName());
        assertEquals("Type1", bean.getMaterialTypeName());
        assertEquals("Unit1", bean.getMaterialUnitName());
        assertEquals("ACTIVE", bean.getStatus());
    }

    @Test
    void testDefaultConstructor() {

        PurchaseBean bean = new PurchaseBean();

        assertNotNull(bean);
    }

    @Test
    void testPurchaseDateBeforeToday() {

        PurchaseBean bean = new PurchaseBean();

        Date yesterday = new Date(
                System.currentTimeMillis() - 24 * 60 * 60 * 1000
        );

        bean.setPurchaseDate(yesterday);

        assertTrue(bean.isPurchaseDateBeforeToday());
    }

    @Test
    void testPurchaseDateNull() {

        PurchaseBean bean = new PurchaseBean();

        bean.setPurchaseDate(null);

        assertTrue(bean.isPurchaseDateBeforeToday());
    }

    @Test
    void testPurchaseDateTodayOrFuture() {

        PurchaseBean bean = new PurchaseBean();

        Date futureDate = new Date(
                System.currentTimeMillis() + 24 * 60 * 60 * 1000
        );

        bean.setPurchaseDate(futureDate);

        assertFalse(bean.isPurchaseDateBeforeToday());
    }

    @Test
    void testBalanceGetterSetter() {

        PurchaseBean bean = new PurchaseBean();

        bean.setBalance(2500.0);

        assertEquals(Double.valueOf(2500.0), bean.getBalance());
    }

    @Test
    void testStatusGetterSetter() {

        PurchaseBean bean = new PurchaseBean();

        bean.setStatus("ACTIVE");

        assertEquals("ACTIVE", bean.getStatus());
    }

    @Test
    void testMaterialCategoryNameGetterSetter() {

        PurchaseBean bean = new PurchaseBean();

        bean.setMaterialCategoryName("Category1");

        assertEquals("Category1", bean.getMaterialCategoryName());
    }

    @Test
    void testMaterialTypeNameGetterSetter() {

        PurchaseBean bean = new PurchaseBean();

        bean.setMaterialTypeName("Type1");

        assertEquals("Type1", bean.getMaterialTypeName());
    }

    @Test
    void testMaterialUnitNameGetterSetter() {

        PurchaseBean bean = new PurchaseBean();

        bean.setMaterialUnitName("Unit1");

        assertEquals("Unit1", bean.getMaterialUnitName());
    }
}