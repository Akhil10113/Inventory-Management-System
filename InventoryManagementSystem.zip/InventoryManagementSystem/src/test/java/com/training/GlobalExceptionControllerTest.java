package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.core.MethodParameter;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.training.exceptions.MicroServiceException;
import com.training.web.controller.GlobalExceptionController;
import com.training.web.controller.GlobalExceptionController.ErrorResponse;

class GlobalExceptionControllerTest {

    private final GlobalExceptionController controller =
            new GlobalExceptionController();

    @Test
    void testHandleAllException() {

        MicroServiceException exception =
                mock(MicroServiceException.class);

        when(exception.getMessage())
                .thenReturn("Microservice error");

        ResponseEntity<ErrorResponse> response =
                controller.handleAllException(exception);

        assertNotNull(response);
        assertEquals(400, response.getStatusCodeValue());

        ErrorResponse body = response.getBody();

        assertNotNull(body);
        assertEquals("ERROR", body.getStatus());
        assertEquals("Microservice error", body.getMessage());
        assertNotNull(body.getErrors());
        assertNotNull(body.getFieldErrors());
    }

    @Test
    void testHandleValidationExceptionWithBindException() {

        BindingResult bindingResult =
                new BeanPropertyBindingResult(new Object(), "object");

        FieldError fieldError =
                new FieldError(
                        "object",
                        "name",
                        "Name is required"
                );

        bindingResult.addError(fieldError);

        BindException exception =
                new BindException(bindingResult);

        ResponseEntity<ErrorResponse> response =
                controller.handleValidationException(exception);

        assertNotNull(response);
        assertEquals(400, response.getStatusCodeValue());

        ErrorResponse body = response.getBody();

        assertNotNull(body);
        assertEquals("ERROR", body.getStatus());

        assertEquals(
                "Name is required",
                body.getMessage()
        );

        assertNotNull(body.getErrors());
        assertTrue(
                body.getErrors().contains("Name is required")
        );

        assertNotNull(body.getFieldErrors());

        assertEquals(
                "Name is required",
                body.getFieldErrors().get("name")
        );
    }

    @Test
    void testHandleValidationExceptionWithMethodArgumentNotValidException() {

        BindingResult bindingResult =
                new BeanPropertyBindingResult(new Object(), "object");

        FieldError fieldError =
                new FieldError(
                        "object",
                        "name",
                        "Name is required"
                );

        bindingResult.addError(fieldError);

        MethodParameter methodParameter =
                mock(MethodParameter.class);

        MethodArgumentNotValidException exception =
                new MethodArgumentNotValidException(
                        methodParameter,
                        bindingResult
                );

        ResponseEntity<ErrorResponse> response =
                controller.handleValidationException(exception);

        assertNotNull(response);
        assertEquals(400, response.getStatusCodeValue());

        ErrorResponse body = response.getBody();

        assertNotNull(body);
        assertEquals("ERROR", body.getStatus());

        assertEquals(
                "Name is required",
                body.getMessage()
        );

        assertNotNull(body.getErrors());

        assertTrue(
                body.getErrors().contains("Name is required")
        );

        assertNotNull(body.getFieldErrors());

        assertEquals(
                "Name is required",
                body.getFieldErrors().get("name")
        );
    }

    @Test
    void testHandleValidationExceptionWithEmptyMessage() {

        BindingResult bindingResult =
                new BeanPropertyBindingResult(new Object(), "object");

        FieldError fieldError =
                new FieldError(
                        "object",
                        "name",
                        ""
                );

        bindingResult.addError(fieldError);

        BindException exception =
                new BindException(bindingResult);

        ResponseEntity<ErrorResponse> response =
                controller.handleValidationException(exception);

        assertNotNull(response);
        assertEquals(400, response.getStatusCodeValue());

        ErrorResponse body = response.getBody();

        assertNotNull(body);

        assertEquals(
                "Validation failed",
                body.getMessage()
        );

        assertNotNull(body.getErrors());
        assertNotNull(body.getFieldErrors());
    }

    @Test
    void testErrorResponseConstructorAndGetters() {

        List<String> errors =
                List.of("Error 1", "Error 2");

        Map<String, String> fieldErrors =
                new HashMap<>();

        fieldErrors.put("name", "Name is required");

        ErrorResponse response =
                new ErrorResponse(
                        "ERROR",
                        "Validation failed",
                        errors,
                        fieldErrors
                );

        assertEquals(
                "ERROR",
                response.getStatus()
        );

        assertEquals(
                "Validation failed",
                response.getMessage()
        );

        assertEquals(
                errors,
                response.getErrors()
        );

        assertEquals(
                fieldErrors,
                response.getFieldErrors()
        );
    }
}